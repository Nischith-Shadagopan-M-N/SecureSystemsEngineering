Here is a link to the video presentation
https://drive.google.com/file/d/1N_7Cmj4dIjCZK3r39cr0Jd6pEfTK0Zeh/view?usp=sharing

P.S. Please note that the video is made with the time limit in mind. For further details please refer to the paper.